from pathlib import Path
from PIL import Image

_RESOURCE_DIR = Path(__file__).parent.parent / "resources"
_IMAGE_PATH = _RESOURCE_DIR / "images" / "source.png"

_MOCK_IMAGE_ATTACHMENT = Image.open(_IMAGE_PATH)
_MOCK_IMAGE_ATTACHMENT.load()


# Exported constants
MOCK_ACCESS_TOKEN = "smartsheetAccessToken{:0>2}"
"""You must use with .format(<int>)"""
MOCK_SHEET_JSON = {
    "id": 7340596407887748,
    "name": "orders",
    "version": 10,
    "totalRowCount": 9,
    "accessLevel": "OWNER",
    "effectiveAttachmentOptions": [
        "GOOGLE_DRIVE",
        "DROPBOX",
        "BOX_COM",
        "EVERNOTE",
        "ONEDRIVE",
        "LINK",
        "FILE",
        "EGNYTE",
    ],
    "ganttEnabled": False,
    "dependenciesEnabled": False,
    "resourceManagementEnabled": False,
    "resourceManagementType": "NONE",
    "cellImageUploadEnabled": True,
    "userSettings": {"criticalPathEnabled": False, "displaySummaryTasks": True},
    "permalink": "https://app.smartsheet.com/sheets/g4J274W3V7F549FvxPVrrWV3fJGCC9xGqjq9Gqm1",
    "createdAt": "2023-02-17T19:00:58Z",
    "modifiedAt": "2023-02-22T22:46:45Z",
    "isMultiPicklistEnabled": True,
    "columns": [
        {
            "id": 3471889768703876,
            "version": 0,
            "index": 0,
            "title": "Name",
            "type": "TEXT_NUMBER",
            "primary": True,
            "validation": False,
            "width": 144,
        },
        {
            "id": 7975489396074372,
            "version": 0,
            "index": 1,
            "title": "Item",
            "type": "TEXT_NUMBER",
            "validation": False,
            "width": 294,
        },
        {
            "id": 657140001597316,
            "version": 0,
            "index": 2,
            "title": "Zip",
            "type": "TEXT_NUMBER",
            "validation": False,
            "width": 51,
        },
    ],
    "rows": [
        {
            "id": 3218304495249284,
            "rowNumber": 1,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-21T21:18:43Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Sol Heaton",
                    "displayValue": "Sol Heaton",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Bolt T-Shirt",
                    "displayValue": "Sauce Labs Bolt T-Shirt",
                },
                {
                    "columnId": 657140001597316,
                    "value": 3695.0,
                    "displayValue": "3695",
                },
            ],
        },
        {
            "id": 7721904122619780,
            "rowNumber": 2,
            "siblingId": 3218304495249284,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Gregg Arroyo",
                    "displayValue": "Gregg Arroyo",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Onesie",
                    "displayValue": "Sauce Labs Onesie",
                },
                {
                    "columnId": 657140001597316,
                    "value": 4418.0,
                    "displayValue": "4418",
                },
            ],
        },
        {
            "id": 2092404588406660,
            "rowNumber": 3,
            "siblingId": 7721904122619780,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Zoya Roche",
                    "displayValue": "Zoya Roche",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Bolt T-Shirt",
                    "displayValue": "Sauce Labs Bolt T-Shirt",
                },
                {
                    "columnId": 657140001597316,
                    "value": 3013.0,
                    "displayValue": "3013",
                },
            ],
        },
        {
            "id": 6596004215777156,
            "rowNumber": 4,
            "siblingId": 2092404588406660,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Gregg Arroyo",
                    "displayValue": "Gregg Arroyo",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Bolt T-Shirt",
                    "displayValue": "Sauce Labs Bolt T-Shirt",
                },
                {
                    "columnId": 657140001597316,
                    "value": 4418.0,
                    "displayValue": "4418",
                },
            ],
        },
        {
            "id": 4344204402091908,
            "rowNumber": 5,
            "siblingId": 6596004215777156,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Camden Martin",
                    "displayValue": "Camden Martin",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Bolt T-Shirt",
                    "displayValue": "Sauce Labs Bolt T-Shirt",
                },
                {
                    "columnId": 657140001597316,
                    "value": 1196.0,
                    "displayValue": "1196",
                },
            ],
        },
        {
            "id": 8847804029462404,
            "rowNumber": 6,
            "siblingId": 4344204402091908,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Zoya Roche",
                    "displayValue": "Zoya Roche",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Fleece Jacket",
                    "displayValue": "Sauce Labs Fleece Jacket",
                },
                {
                    "columnId": 657140001597316,
                    "value": 3013.0,
                    "displayValue": "3013",
                },
            ],
        },
        {
            "id": 262817239787396,
            "rowNumber": 7,
            "siblingId": 8847804029462404,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Zoya Roche",
                    "displayValue": "Zoya Roche",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Onesie",
                    "displayValue": "Sauce Labs Onesie",
                },
                {
                    "columnId": 657140001597316,
                    "value": 3013.0,
                    "displayValue": "3013",
                },
            ],
        },
        {
            "id": 4766416867157892,
            "rowNumber": 8,
            "siblingId": 262817239787396,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Sol Heaton",
                    "displayValue": "Sol Heaton",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Fleece Jacket",
                    "displayValue": "Sauce Labs Fleece Jacket",
                },
                {
                    "columnId": 657140001597316,
                    "value": 3695.0,
                    "displayValue": "3695",
                },
            ],
        },
        {
            "id": 2514617053472644,
            "rowNumber": 9,
            "siblingId": 4766416867157892,
            "expanded": True,
            "createdAt": "2023-02-17T19:00:58Z",
            "modifiedAt": "2023-02-17T19:00:58Z",
            "cells": [
                {
                    "columnId": 3471889768703876,
                    "value": "Sol Heaton",
                    "displayValue": "Sol Heaton",
                },
                {
                    "columnId": 7975489396074372,
                    "value": "Sauce Labs Onesee",
                    "displayValue": "Sauce Labs Onesee",
                },
                {
                    "columnId": 657140001597316,
                    "value": 3695.0,
                    "displayValue": "3695",
                },
            ],
        },
    ],
}
"""A mocked sheet response"""
MOCK_IMAGE = _MOCK_IMAGE_ATTACHMENT.tobytes()
"""An image in bytes"""
MOCK_IMAGE_ATTACHMENT = {
    "expected_filename": "source.png",
    "expected_content": MOCK_IMAGE,
}
"""A mocked image attachment"""
MOCK_TEXT_ATTACHMENT = {
    "expected_filename": "note01}.txt",
    "expected_content": "Hello World! I'm note number 01!",
}
"""A mocked text attachment, use with `.format(<int>)`."""
ATTACHMENT_NODE = {
    "id": None,
    "name": None,
    "attachmentType": "FILE",
    "mimeType": None,
    "sizeInKb": 1,
    "createdAt": "2023-02-22T22:47:26Z",
    "createdBy": {"email": "markmonkey@robocorp.com"},
}
"""You should set the `id`, `name`, and `mimeType` attributes of this dict."""
_attach_one = ATTACHMENT_NODE.copy()
_attach_one["id"] = 123
_attach_one["name"] = "source.png"
_attach_one["mimeType"] = "image/png"
_attach_two = ATTACHMENT_NODE.copy()
_attach_two["id"] = 456
_attach_two["name"] = "note01.txt"
_attach_two["mimeType"] = "text/plain"
MOCKED_ATTACHMENT_LIST = [_attach_one, _attach_two]
