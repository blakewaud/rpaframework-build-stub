import os
from pathlib import Path
from json.encoder import JSONEncoder
from requests.models import Response, PreparedRequest
from typing import Union, Iterable

import pytest
from mock import MagicMock, patch
from pytest_mock import MockerFixture


import smartsheet.smartsheet as smart_sdk

OperationResult = smart_sdk.OperationResult
OperationErrorResult = smart_sdk.OperationErrorResult

from RPA.Tables import Table
import RPA.Smartsheet as ss

Smartsheet = ss.Smartsheet

# You can set a personal testing token via the smartsheet_testvars.py file
try:
    from .smartsheet_testvars import ACCESS_TOKEN, ORDERS_COLS

    VARS = True
except ImportError:
    VARS = False

# Import mock data
from .smartsheet_vars import (
    MOCK_ACCESS_TOKEN,
    MOCK_SHEET_JSON,
    MOCK_IMAGE_ATTACHMENT,
    MOCK_TEXT_ATTACHMENT,
    MOCKED_ATTACHMENT_LIST,
)


# Testing Constants
TEMP_DIR = Path(__file__).parent.parent / "results"


# @skip  # Need to skip if smartsheet_testvars could not be imported
@pytest.mark.skip("Test only used for debugging")
def test_debugging():
    """This test should always be skipped for automated tests."""
    lib = Smartsheet(access_token=ACCESS_TOKEN)
    orders = lib.get_sheet(sheet_name="orders")
    attachments = lib.list_attachments()
    for a in attachments:
        lib.download_attachment(a, TEMP_DIR)


@pytest.fixture
def library() -> Smartsheet:
    return Smartsheet()


@pytest.fixture
def authorized_lib(
    library: Smartsheet, mocker: MockerFixture, iter: int = 1
) -> Smartsheet:
    library.set_access_token(MOCK_ACCESS_TOKEN.format(iter))
    return library


@pytest.fixture
def lib_with_sheet(authorized_lib: Smartsheet, mocker: MockerFixture) -> Smartsheet:
    _patch_response(authorized_lib, mocker, MOCK_SHEET_JSON)
    authorized_lib.get_sheet(7340596407887748)
    return authorized_lib


def _create_json_response(return_value: dict) -> MagicMock:
    mock_response = MagicMock(Response)
    mock_response.status_code = 200
    mock_response.reason = "OK"
    mock_response.headers = {"Content-Type": "application/json"}
    mock_response.json.return_value = return_value
    mock_response.text = JSONEncoder().encode(return_value)
    mock_response.content.decode.return_value = mock_response.text
    mock_response.request = MagicMock(PreparedRequest)
    mock_response.request.method = "TEST"
    mock_response.request.url = "TEST"
    mock_response.request.body = None
    return mock_response


def _create_file_response(
    expected_filename: str,
    expected_content: Union[str, bytes],
    mime_type: str = "text/plain;charset=UTF-8",
) -> list[MagicMock]:
    json_response = {
        "id": 123,
        "name": expected_filename,
        "url": "http://localhost",
        "attachmentType": "FILE",
        "mimeType": mime_type,
        "urlExpiresInMillis": 120000,
        "sizeInKb": 1,
        "parentType": "ROW",
        "parentId": 456,
        "createdAt": "2023-02-22T22:46:44Z",
        "createdBy": {"email": "markmonkey@robocorp.com"},
    }
    json_mock = _create_json_response(json_response)
    file_response = MagicMock()
    file_response.content = (
        expected_content
        if isinstance(expected_content, bytes)
        else expected_content.encode()
    )
    file_response.status_code = 200
    file_response.iter_content.return_value = iter([expected_content])
    return [json_mock, file_response]


def _patch_file_response(
    mocker: MockerFixture,
    expected_content: Union[str, bytes],
    mime_type: str = "text/plain;charset=UTF-8",
) -> MagicMock:
    mock_get = mocker.patch("smartsheet.attachments.requests.get")
    mock_get.return_value = _create_file_response(mocker, expected_content, mime_type)
    return mock_get


def _patch_multiple_file_responses(
    mocker: MockerFixture, file_responses: Iterable[MagicMock]
) -> MagicMock:
    mock_get = mocker.patch("smartsheet.attachments.requests.get")
    mock_get.side_effect = file_responses
    return mock_get


def _patch_response(
    library: Smartsheet, mocker: MockerFixture, return_value: dict
) -> MagicMock:
    mock_response = _create_json_response(return_value)
    config = {"return_value": mock_response}
    return mocker.patch.object(library.smart._session, "send", **config)


def _patch_multiple_responses(
    library: Smartsheet, mocker: MockerFixture, mocked_responses: Iterable[MagicMock]
) -> MagicMock:
    config = {"side_effect": mocked_responses}
    return mocker.patch.object(library.smart._session, "send", **config)


def test_authorization(library: Smartsheet, mocker: MockerFixture) -> None:
    mock_client = mocker.patch("RPA.Smartsheet.smart_sdk", autospec=True)

    library.set_access_token(MOCK_ACCESS_TOKEN)

    mock_client.assert_called()


def test_get_application_constants(
    authorized_lib: Smartsheet, mocker: MockerFixture
) -> None:
    expected_response = {"supportedLocales": ["en_US"], "serverVersion": "207.0.0"}
    patch = _patch_response(authorized_lib, mocker, expected_response)

    server_info = authorized_lib.get_application_constants()

    patch.assert_called()
    assert list(server_info.supported_locales) == ["en_US"]


def test_get_me(authorized_lib: Smartsheet, mocker: MockerFixture) -> None:
    expected_response = {
        "id": 123123,
        "email": "markmonkey@robocorp.com",
        "locale": "en_US",
        "timeZone": "US/Pacific",
        "account": {
            "name": "markmonkey@robocorp.com (Developer)",
            "id": 789789,
        },
        "admin": True,
        "licensedSheetCreator": True,
        "groupAdmin": True,
        "resourceViewer": True,
        "alternateEmails": [],
        "sheetCount": 25,
        "lastLogin": "2023-02-28T18:15:56Z",
        "title": "",
        "department": "",
        "company": "",
        "workPhone": "",
        "mobilePhone": "",
        "role": "",
    }
    patch = _patch_response(authorized_lib, mocker, expected_response)

    me = authorized_lib.get_current_user()

    patch.assert_called()
    assert me.email == expected_response["email"]


def test_get_sheet(authorized_lib: Smartsheet, mocker: MockerFixture) -> None:
    patch = _patch_response(authorized_lib, mocker, MOCK_SHEET_JSON)

    sheet = authorized_lib.get_sheet(123, native=True)

    patch.assert_called()
    assert sheet.id == MOCK_SHEET_JSON["id"]
    assert [c.title for c in sheet.columns] == [
        c["title"] for c in MOCK_SHEET_JSON["columns"]
    ]
    for row in sheet.rows:
        assert row.id in [r["id"] for r in MOCK_SHEET_JSON["rows"]]


def test_convert_sheet_to_table(
    lib_with_sheet: Smartsheet, mocker: MockerFixture
) -> None:
    table = lib_with_sheet.convert_sheet_to_table()

    assert isinstance(table, Table)
    assert table.columns == [c["title"] for c in MOCK_SHEET_JSON["columns"]]
    for table_row, sheet_row in zip(table, MOCK_SHEET_JSON["rows"]):
        assert list(table_row.values()) == [
            cell["value"] for cell in sheet_row["cells"]
        ]


def test_download_attachment(lib_with_sheet: Smartsheet, mocker: MockerFixture) -> None:
    expected_content = "dummy file content"
    mock_get = _patch_file_response(mocker, expected_content)

    downloaded_file = lib_with_sheet.download_attachment(123, TEMP_DIR)

    mock_get.assert_called()
    assert downloaded_file
    assert downloaded_file.exists()
    assert downloaded_file.read_text() == str(expected_content, "utf8")


def test_get_sheet_with_attachments(
    authorized_lib: Smartsheet, mocker: MockerFixture
) -> None:
    mock_sheet = MOCK_SHEET_JSON.copy()
    mock_sheet["rows"][0]["attachments"] = MOCKED_ATTACHMENT_LIST
    _patch_response(authorized_lib, mocker, mock_sheet)
    attachments = [
        MOCK_IMAGE_ATTACHMENT,
        MOCK_TEXT_ATTACHMENT,
    ]
    file_responses = []
    for attachment in attachments:
        file_responses.extend(
            _create_file_response(
                attachment["expected_content"],
                attachment["expected_filename"],
            )
        )
    patches = _patch_multiple_file_responses(mocker, file_responses)

    sheet_with_attachments: Table = authorized_lib.get_sheet(123, include="ALL")

    assert authorized_lib.current_sheet.selected_includes == [
        "attachments",
        "attachmentFiles",
        "discussions",
        "rowPermalink",
    ]
    files = sheet_with_attachments[:, "attachmentFiles"]
    for file, expected_content in zip(files, attachments):
        assert file.exists()
        assert file.read_text() == expected_content["expected_content"]
    patches.assert_called()
