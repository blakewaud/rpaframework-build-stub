# $key = "3QRhVvzOZdfrsFoyODRgLrgLZlhPwNkpLhZHG" # farmer's
$key = "rpmCAkGhctxKxWAwcpyr0ocv3KNeK1XMrILCx" # mine
$base_url = "https://api.smartsheet.com/2.0"
function Call-Smartsheet {
    param (
        $url
    )
    $response = curl "$base_url$url" -sH "Authorization: Bearer $key"
    try {
        $parsed = ConvertFrom-Json  $response  
        return $parsed
    }
    catch {
        return $response
    }
}

function Curl-Smartsheet {
    param (
        $url
    )
    $response = curl "$base_url$url" -sH "Authorization: Bearer $key"
    return $response

}

function Get-Attachments {
    param (
        $sheetId
    )
    $attachments = Call-Smartsheet "/sheets/$sheetId/attachments"
    return $attachments
    
}

function Download-Attachment {
    param (
        $sheetId,
        $attachmentId

    )
    $attachment = Call-Smartsheet "/sheets/$sheetId/attachments/$attachmentId"
    return $attachment
}

function Get-Sheets {
    $sheets = Call-Smartsheet "/sheets?includeAll=true"
    return $sheets.data
}

function Main {
    $sheets = Get-Sheets
    foreach ($sheet in $sheets) {
        $attachments = Get-Attachments $sheet.id
        if ($attachments.totalCount -gt 0) {
            Write-Output "Use: $($sheet.name) with id $($sheet.id)"
        }
    }
}
